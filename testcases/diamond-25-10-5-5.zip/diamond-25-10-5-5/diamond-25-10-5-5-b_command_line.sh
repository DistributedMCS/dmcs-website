#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/diamond-25-10-5-5-b-1.lp --br=$TESTSPATH/diamond-25-10-5-5-b-1.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/diamond-25-10-5-5-b-2.lp --br=$TESTSPATH/diamond-25-10-5-5-b-2.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/diamond-25-10-5-5-b-3.lp --br=$TESTSPATH/diamond-25-10-5-5-b-3.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/diamond-25-10-5-5-b-4.lp --br=$TESTSPATH/diamond-25-10-5-5-b-4.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/diamond-25-10-5-5-b-5.lp --br=$TESTSPATH/diamond-25-10-5-5-b-5.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/diamond-25-10-5-5-b-6.lp --br=$TESTSPATH/diamond-25-10-5-5-b-6.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/diamond-25-10-5-5-b-7.lp --br=$TESTSPATH/diamond-25-10-5-5-b-7.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/diamond-25-10-5-5-b-8.lp --br=$TESTSPATH/diamond-25-10-5-5-b-8.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/diamond-25-10-5-5-b-9.lp --br=$TESTSPATH/diamond-25-10-5-5-b-9.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/diamond-25-10-5-5-b-10.lp --br=$TESTSPATH/diamond-25-10-5-5-b-10.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=11 --port=5011 --kb=$TESTSPATH/diamond-25-10-5-5-b-11.lp --br=$TESTSPATH/diamond-25-10-5-5-b-11.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=12 --port=5012 --kb=$TESTSPATH/diamond-25-10-5-5-b-12.lp --br=$TESTSPATH/diamond-25-10-5-5-b-12.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=13 --port=5013 --kb=$TESTSPATH/diamond-25-10-5-5-b-13.lp --br=$TESTSPATH/diamond-25-10-5-5-b-13.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=14 --port=5014 --kb=$TESTSPATH/diamond-25-10-5-5-b-14.lp --br=$TESTSPATH/diamond-25-10-5-5-b-14.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=15 --port=5015 --kb=$TESTSPATH/diamond-25-10-5-5-b-15.lp --br=$TESTSPATH/diamond-25-10-5-5-b-15.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=16 --port=5016 --kb=$TESTSPATH/diamond-25-10-5-5-b-16.lp --br=$TESTSPATH/diamond-25-10-5-5-b-16.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=17 --port=5017 --kb=$TESTSPATH/diamond-25-10-5-5-b-17.lp --br=$TESTSPATH/diamond-25-10-5-5-b-17.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=18 --port=5018 --kb=$TESTSPATH/diamond-25-10-5-5-b-18.lp --br=$TESTSPATH/diamond-25-10-5-5-b-18.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=19 --port=5019 --kb=$TESTSPATH/diamond-25-10-5-5-b-19.lp --br=$TESTSPATH/diamond-25-10-5-5-b-19.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=20 --port=5020 --kb=$TESTSPATH/diamond-25-10-5-5-b-20.lp --br=$TESTSPATH/diamond-25-10-5-5-b-20.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=21 --port=5021 --kb=$TESTSPATH/diamond-25-10-5-5-b-21.lp --br=$TESTSPATH/diamond-25-10-5-5-b-21.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=22 --port=5022 --kb=$TESTSPATH/diamond-25-10-5-5-b-22.lp --br=$TESTSPATH/diamond-25-10-5-5-b-22.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=23 --port=5023 --kb=$TESTSPATH/diamond-25-10-5-5-b-23.lp --br=$TESTSPATH/diamond-25-10-5-5-b-23.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=24 --port=5024 --kb=$TESTSPATH/diamond-25-10-5-5-b-24.lp --br=$TESTSPATH/diamond-25-10-5-5-b-24.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=25 --port=5025 --kb=$TESTSPATH/diamond-25-10-5-5-b-25.lp --br=$TESTSPATH/diamond-25-10-5-5-b-25.br --topology=$TESTSPATH/diamond-25-10-5-5-b.top >/dev/null 2>&1 &
/usr/bin/time --portability -o diamond-25-10-5-5-b-dmcs-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=25 --query-variables="18446744073709551615 17 5 1121 1281 65 931 193 897 1351 41 45 61 1091 1025 1617 9 385 527 131 5 795 897 1057 647 " > diamond-25-10-5-5-b-dmcs.log 2> diamond-25-10-5-5-b-dmcs-err.log
killall dmcsd
