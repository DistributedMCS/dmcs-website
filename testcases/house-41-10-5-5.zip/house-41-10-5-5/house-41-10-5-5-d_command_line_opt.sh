#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/house-41-10-5-5-d-1.lp --br=$TESTSPATH/house-41-10-5-5-d-1.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/house-41-10-5-5-d-2.lp --br=$TESTSPATH/house-41-10-5-5-d-2.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/house-41-10-5-5-d-3.lp --br=$TESTSPATH/house-41-10-5-5-d-3.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/house-41-10-5-5-d-4.lp --br=$TESTSPATH/house-41-10-5-5-d-4.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/house-41-10-5-5-d-5.lp --br=$TESTSPATH/house-41-10-5-5-d-5.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/house-41-10-5-5-d-6.lp --br=$TESTSPATH/house-41-10-5-5-d-6.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/house-41-10-5-5-d-7.lp --br=$TESTSPATH/house-41-10-5-5-d-7.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/house-41-10-5-5-d-8.lp --br=$TESTSPATH/house-41-10-5-5-d-8.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/house-41-10-5-5-d-9.lp --br=$TESTSPATH/house-41-10-5-5-d-9.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/house-41-10-5-5-d-10.lp --br=$TESTSPATH/house-41-10-5-5-d-10.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=11 --port=5011 --kb=$TESTSPATH/house-41-10-5-5-d-11.lp --br=$TESTSPATH/house-41-10-5-5-d-11.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=12 --port=5012 --kb=$TESTSPATH/house-41-10-5-5-d-12.lp --br=$TESTSPATH/house-41-10-5-5-d-12.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=13 --port=5013 --kb=$TESTSPATH/house-41-10-5-5-d-13.lp --br=$TESTSPATH/house-41-10-5-5-d-13.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=14 --port=5014 --kb=$TESTSPATH/house-41-10-5-5-d-14.lp --br=$TESTSPATH/house-41-10-5-5-d-14.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=15 --port=5015 --kb=$TESTSPATH/house-41-10-5-5-d-15.lp --br=$TESTSPATH/house-41-10-5-5-d-15.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=16 --port=5016 --kb=$TESTSPATH/house-41-10-5-5-d-16.lp --br=$TESTSPATH/house-41-10-5-5-d-16.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=17 --port=5017 --kb=$TESTSPATH/house-41-10-5-5-d-17.lp --br=$TESTSPATH/house-41-10-5-5-d-17.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=18 --port=5018 --kb=$TESTSPATH/house-41-10-5-5-d-18.lp --br=$TESTSPATH/house-41-10-5-5-d-18.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=19 --port=5019 --kb=$TESTSPATH/house-41-10-5-5-d-19.lp --br=$TESTSPATH/house-41-10-5-5-d-19.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=20 --port=5020 --kb=$TESTSPATH/house-41-10-5-5-d-20.lp --br=$TESTSPATH/house-41-10-5-5-d-20.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=21 --port=5021 --kb=$TESTSPATH/house-41-10-5-5-d-21.lp --br=$TESTSPATH/house-41-10-5-5-d-21.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=22 --port=5022 --kb=$TESTSPATH/house-41-10-5-5-d-22.lp --br=$TESTSPATH/house-41-10-5-5-d-22.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=23 --port=5023 --kb=$TESTSPATH/house-41-10-5-5-d-23.lp --br=$TESTSPATH/house-41-10-5-5-d-23.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=24 --port=5024 --kb=$TESTSPATH/house-41-10-5-5-d-24.lp --br=$TESTSPATH/house-41-10-5-5-d-24.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=25 --port=5025 --kb=$TESTSPATH/house-41-10-5-5-d-25.lp --br=$TESTSPATH/house-41-10-5-5-d-25.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=26 --port=5026 --kb=$TESTSPATH/house-41-10-5-5-d-26.lp --br=$TESTSPATH/house-41-10-5-5-d-26.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=27 --port=5027 --kb=$TESTSPATH/house-41-10-5-5-d-27.lp --br=$TESTSPATH/house-41-10-5-5-d-27.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=28 --port=5028 --kb=$TESTSPATH/house-41-10-5-5-d-28.lp --br=$TESTSPATH/house-41-10-5-5-d-28.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=29 --port=5029 --kb=$TESTSPATH/house-41-10-5-5-d-29.lp --br=$TESTSPATH/house-41-10-5-5-d-29.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=30 --port=5030 --kb=$TESTSPATH/house-41-10-5-5-d-30.lp --br=$TESTSPATH/house-41-10-5-5-d-30.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=31 --port=5031 --kb=$TESTSPATH/house-41-10-5-5-d-31.lp --br=$TESTSPATH/house-41-10-5-5-d-31.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=32 --port=5032 --kb=$TESTSPATH/house-41-10-5-5-d-32.lp --br=$TESTSPATH/house-41-10-5-5-d-32.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=33 --port=5033 --kb=$TESTSPATH/house-41-10-5-5-d-33.lp --br=$TESTSPATH/house-41-10-5-5-d-33.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=34 --port=5034 --kb=$TESTSPATH/house-41-10-5-5-d-34.lp --br=$TESTSPATH/house-41-10-5-5-d-34.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=35 --port=5035 --kb=$TESTSPATH/house-41-10-5-5-d-35.lp --br=$TESTSPATH/house-41-10-5-5-d-35.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=36 --port=5036 --kb=$TESTSPATH/house-41-10-5-5-d-36.lp --br=$TESTSPATH/house-41-10-5-5-d-36.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=37 --port=5037 --kb=$TESTSPATH/house-41-10-5-5-d-37.lp --br=$TESTSPATH/house-41-10-5-5-d-37.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=38 --port=5038 --kb=$TESTSPATH/house-41-10-5-5-d-38.lp --br=$TESTSPATH/house-41-10-5-5-d-38.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=39 --port=5039 --kb=$TESTSPATH/house-41-10-5-5-d-39.lp --br=$TESTSPATH/house-41-10-5-5-d-39.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=40 --port=5040 --kb=$TESTSPATH/house-41-10-5-5-d-40.lp --br=$TESTSPATH/house-41-10-5-5-d-40.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=41 --port=5041 --kb=$TESTSPATH/house-41-10-5-5-d-41.lp --br=$TESTSPATH/house-41-10-5-5-d-41.br --topology=$TESTSPATH/house-41-10-5-5-d.opt >/dev/null 2>&1 &
/usr/bin/time --portability -o house-41-10-5-5-d-dmcsopt-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=41 > house-41-10-5-5-d-dmcsopt.log 2> house-41-10-5-5-d-dmcsopt-err.log
killall dmcsd
