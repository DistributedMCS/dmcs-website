#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/house-41-10-5-5-h-1.lp --br=$TESTSPATH/house-41-10-5-5-h-1.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/house-41-10-5-5-h-2.lp --br=$TESTSPATH/house-41-10-5-5-h-2.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/house-41-10-5-5-h-3.lp --br=$TESTSPATH/house-41-10-5-5-h-3.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/house-41-10-5-5-h-4.lp --br=$TESTSPATH/house-41-10-5-5-h-4.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/house-41-10-5-5-h-5.lp --br=$TESTSPATH/house-41-10-5-5-h-5.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/house-41-10-5-5-h-6.lp --br=$TESTSPATH/house-41-10-5-5-h-6.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/house-41-10-5-5-h-7.lp --br=$TESTSPATH/house-41-10-5-5-h-7.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/house-41-10-5-5-h-8.lp --br=$TESTSPATH/house-41-10-5-5-h-8.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/house-41-10-5-5-h-9.lp --br=$TESTSPATH/house-41-10-5-5-h-9.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/house-41-10-5-5-h-10.lp --br=$TESTSPATH/house-41-10-5-5-h-10.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=11 --port=5011 --kb=$TESTSPATH/house-41-10-5-5-h-11.lp --br=$TESTSPATH/house-41-10-5-5-h-11.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=12 --port=5012 --kb=$TESTSPATH/house-41-10-5-5-h-12.lp --br=$TESTSPATH/house-41-10-5-5-h-12.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=13 --port=5013 --kb=$TESTSPATH/house-41-10-5-5-h-13.lp --br=$TESTSPATH/house-41-10-5-5-h-13.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=14 --port=5014 --kb=$TESTSPATH/house-41-10-5-5-h-14.lp --br=$TESTSPATH/house-41-10-5-5-h-14.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=15 --port=5015 --kb=$TESTSPATH/house-41-10-5-5-h-15.lp --br=$TESTSPATH/house-41-10-5-5-h-15.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=16 --port=5016 --kb=$TESTSPATH/house-41-10-5-5-h-16.lp --br=$TESTSPATH/house-41-10-5-5-h-16.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=17 --port=5017 --kb=$TESTSPATH/house-41-10-5-5-h-17.lp --br=$TESTSPATH/house-41-10-5-5-h-17.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=18 --port=5018 --kb=$TESTSPATH/house-41-10-5-5-h-18.lp --br=$TESTSPATH/house-41-10-5-5-h-18.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=19 --port=5019 --kb=$TESTSPATH/house-41-10-5-5-h-19.lp --br=$TESTSPATH/house-41-10-5-5-h-19.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=20 --port=5020 --kb=$TESTSPATH/house-41-10-5-5-h-20.lp --br=$TESTSPATH/house-41-10-5-5-h-20.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=21 --port=5021 --kb=$TESTSPATH/house-41-10-5-5-h-21.lp --br=$TESTSPATH/house-41-10-5-5-h-21.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=22 --port=5022 --kb=$TESTSPATH/house-41-10-5-5-h-22.lp --br=$TESTSPATH/house-41-10-5-5-h-22.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=23 --port=5023 --kb=$TESTSPATH/house-41-10-5-5-h-23.lp --br=$TESTSPATH/house-41-10-5-5-h-23.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=24 --port=5024 --kb=$TESTSPATH/house-41-10-5-5-h-24.lp --br=$TESTSPATH/house-41-10-5-5-h-24.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=25 --port=5025 --kb=$TESTSPATH/house-41-10-5-5-h-25.lp --br=$TESTSPATH/house-41-10-5-5-h-25.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=26 --port=5026 --kb=$TESTSPATH/house-41-10-5-5-h-26.lp --br=$TESTSPATH/house-41-10-5-5-h-26.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=27 --port=5027 --kb=$TESTSPATH/house-41-10-5-5-h-27.lp --br=$TESTSPATH/house-41-10-5-5-h-27.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=28 --port=5028 --kb=$TESTSPATH/house-41-10-5-5-h-28.lp --br=$TESTSPATH/house-41-10-5-5-h-28.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=29 --port=5029 --kb=$TESTSPATH/house-41-10-5-5-h-29.lp --br=$TESTSPATH/house-41-10-5-5-h-29.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=30 --port=5030 --kb=$TESTSPATH/house-41-10-5-5-h-30.lp --br=$TESTSPATH/house-41-10-5-5-h-30.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=31 --port=5031 --kb=$TESTSPATH/house-41-10-5-5-h-31.lp --br=$TESTSPATH/house-41-10-5-5-h-31.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=32 --port=5032 --kb=$TESTSPATH/house-41-10-5-5-h-32.lp --br=$TESTSPATH/house-41-10-5-5-h-32.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=33 --port=5033 --kb=$TESTSPATH/house-41-10-5-5-h-33.lp --br=$TESTSPATH/house-41-10-5-5-h-33.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=34 --port=5034 --kb=$TESTSPATH/house-41-10-5-5-h-34.lp --br=$TESTSPATH/house-41-10-5-5-h-34.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=35 --port=5035 --kb=$TESTSPATH/house-41-10-5-5-h-35.lp --br=$TESTSPATH/house-41-10-5-5-h-35.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=36 --port=5036 --kb=$TESTSPATH/house-41-10-5-5-h-36.lp --br=$TESTSPATH/house-41-10-5-5-h-36.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=37 --port=5037 --kb=$TESTSPATH/house-41-10-5-5-h-37.lp --br=$TESTSPATH/house-41-10-5-5-h-37.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=38 --port=5038 --kb=$TESTSPATH/house-41-10-5-5-h-38.lp --br=$TESTSPATH/house-41-10-5-5-h-38.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=39 --port=5039 --kb=$TESTSPATH/house-41-10-5-5-h-39.lp --br=$TESTSPATH/house-41-10-5-5-h-39.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=40 --port=5040 --kb=$TESTSPATH/house-41-10-5-5-h-40.lp --br=$TESTSPATH/house-41-10-5-5-h-40.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=41 --port=5041 --kb=$TESTSPATH/house-41-10-5-5-h-41.lp --br=$TESTSPATH/house-41-10-5-5-h-41.br --topology=$TESTSPATH/house-41-10-5-5-h.top >/dev/null 2>&1 &
/usr/bin/time --portability -o house-41-10-5-5-h-dmcs-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=41 --query-variables="18446744073709551615 1555 341 289 5 145 1241 293 81 89 611 1449 17 385 193 337 19 77 1157 1073 73 1641 1153 265 37 1605 779 21 11 779 581 1041 1329 649 85 533 513 273 1125 1609 13 " > house-41-10-5-5-h-dmcs.log 2> house-41-10-5-5-h-dmcs-err.log
killall dmcsd
