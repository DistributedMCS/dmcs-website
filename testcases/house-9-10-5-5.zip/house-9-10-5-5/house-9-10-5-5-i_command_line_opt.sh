#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/house-9-10-5-5-i-1.lp --br=$TESTSPATH/house-9-10-5-5-i-1.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/house-9-10-5-5-i-2.lp --br=$TESTSPATH/house-9-10-5-5-i-2.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/house-9-10-5-5-i-3.lp --br=$TESTSPATH/house-9-10-5-5-i-3.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/house-9-10-5-5-i-4.lp --br=$TESTSPATH/house-9-10-5-5-i-4.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/house-9-10-5-5-i-5.lp --br=$TESTSPATH/house-9-10-5-5-i-5.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/house-9-10-5-5-i-6.lp --br=$TESTSPATH/house-9-10-5-5-i-6.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/house-9-10-5-5-i-7.lp --br=$TESTSPATH/house-9-10-5-5-i-7.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/house-9-10-5-5-i-8.lp --br=$TESTSPATH/house-9-10-5-5-i-8.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/house-9-10-5-5-i-9.lp --br=$TESTSPATH/house-9-10-5-5-i-9.br --topology=$TESTSPATH/house-9-10-5-5-i.opt >/dev/null 2>&1 &
/usr/bin/time --portability -o house-9-10-5-5-i-dmcsopt-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=9 > house-9-10-5-5-i-dmcsopt.log 2> house-9-10-5-5-i-dmcsopt-err.log
killall dmcsd
