#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/diamond-10-10-5-5-g-1.lp --br=$TESTSPATH/diamond-10-10-5-5-g-1.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/diamond-10-10-5-5-g-2.lp --br=$TESTSPATH/diamond-10-10-5-5-g-2.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/diamond-10-10-5-5-g-3.lp --br=$TESTSPATH/diamond-10-10-5-5-g-3.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/diamond-10-10-5-5-g-4.lp --br=$TESTSPATH/diamond-10-10-5-5-g-4.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/diamond-10-10-5-5-g-5.lp --br=$TESTSPATH/diamond-10-10-5-5-g-5.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/diamond-10-10-5-5-g-6.lp --br=$TESTSPATH/diamond-10-10-5-5-g-6.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/diamond-10-10-5-5-g-7.lp --br=$TESTSPATH/diamond-10-10-5-5-g-7.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/diamond-10-10-5-5-g-8.lp --br=$TESTSPATH/diamond-10-10-5-5-g-8.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/diamond-10-10-5-5-g-9.lp --br=$TESTSPATH/diamond-10-10-5-5-g-9.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/diamond-10-10-5-5-g-10.lp --br=$TESTSPATH/diamond-10-10-5-5-g-10.br --topology=$TESTSPATH/diamond-10-10-5-5-g.top >/dev/null 2>&1 &
/usr/bin/time --portability -o diamond-10-10-5-5-g-dmcs-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=10 --query-variables="18446744073709551615 145 1037 1281 1025 1089 1541 31 17 313 " > diamond-10-10-5-5-g-dmcs.log 2> diamond-10-10-5-5-g-dmcs-err.log
killall dmcsd
