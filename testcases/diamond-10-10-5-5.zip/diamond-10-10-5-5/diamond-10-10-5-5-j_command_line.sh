#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/diamond-10-10-5-5-j-1.lp --br=$TESTSPATH/diamond-10-10-5-5-j-1.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/diamond-10-10-5-5-j-2.lp --br=$TESTSPATH/diamond-10-10-5-5-j-2.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/diamond-10-10-5-5-j-3.lp --br=$TESTSPATH/diamond-10-10-5-5-j-3.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/diamond-10-10-5-5-j-4.lp --br=$TESTSPATH/diamond-10-10-5-5-j-4.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/diamond-10-10-5-5-j-5.lp --br=$TESTSPATH/diamond-10-10-5-5-j-5.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/diamond-10-10-5-5-j-6.lp --br=$TESTSPATH/diamond-10-10-5-5-j-6.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/diamond-10-10-5-5-j-7.lp --br=$TESTSPATH/diamond-10-10-5-5-j-7.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/diamond-10-10-5-5-j-8.lp --br=$TESTSPATH/diamond-10-10-5-5-j-8.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/diamond-10-10-5-5-j-9.lp --br=$TESTSPATH/diamond-10-10-5-5-j-9.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/diamond-10-10-5-5-j-10.lp --br=$TESTSPATH/diamond-10-10-5-5-j-10.br --topology=$TESTSPATH/diamond-10-10-5-5-j.top >/dev/null 2>&1 &
/usr/bin/time --portability -o diamond-10-10-5-5-j-dmcs-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=10 --query-variables="18446744073709551615 73 9 1131 569 17 333 41 1043 1445 " > diamond-10-10-5-5-j-dmcs.log 2> diamond-10-10-5-5-j-dmcs-err.log
killall dmcsd
