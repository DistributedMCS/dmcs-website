#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-1.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-1.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-2.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-2.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-3.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-3.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-4.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-4.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-5.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-5.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-6.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-6.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-7.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-7.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-8.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-8.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-9.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-9.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/zig-zag-10-10-5-5-b-10.lp --br=$TESTSPATH/zig-zag-10-10-5-5-b-10.br --topology=$TESTSPATH/zig-zag-10-10-5-5-b.top >/dev/null 2>&1 &
/usr/bin/time --portability -o zig-zag-10-10-5-5-b-dmcs-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=10 --query-variables="18446744073709551615 133 281 267 5 193 647 35 69 593 " > zig-zag-10-10-5-5-b-dmcs.log 2> zig-zag-10-10-5-5-b-dmcs-err.log
killall dmcsd
