#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/ring-10-10-5-5-d-1.lp --br=$TESTSPATH/ring-10-10-5-5-d-1.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/ring-10-10-5-5-d-2.lp --br=$TESTSPATH/ring-10-10-5-5-d-2.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/ring-10-10-5-5-d-3.lp --br=$TESTSPATH/ring-10-10-5-5-d-3.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/ring-10-10-5-5-d-4.lp --br=$TESTSPATH/ring-10-10-5-5-d-4.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/ring-10-10-5-5-d-5.lp --br=$TESTSPATH/ring-10-10-5-5-d-5.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/ring-10-10-5-5-d-6.lp --br=$TESTSPATH/ring-10-10-5-5-d-6.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/ring-10-10-5-5-d-7.lp --br=$TESTSPATH/ring-10-10-5-5-d-7.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/ring-10-10-5-5-d-8.lp --br=$TESTSPATH/ring-10-10-5-5-d-8.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/ring-10-10-5-5-d-9.lp --br=$TESTSPATH/ring-10-10-5-5-d-9.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/ring-10-10-5-5-d-10.lp --br=$TESTSPATH/ring-10-10-5-5-d-10.br --topology=$TESTSPATH/ring-10-10-5-5-d.opt >/dev/null 2>&1 &
/usr/bin/time --portability -o ring-10-10-5-5-d-dmcsopt-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=10 > ring-10-10-5-5-d-dmcsopt.log 2> ring-10-10-5-5-d-dmcsopt-err.log
killall dmcsd
