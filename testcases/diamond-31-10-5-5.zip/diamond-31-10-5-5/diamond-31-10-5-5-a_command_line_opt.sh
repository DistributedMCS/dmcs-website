#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests'
export DMCSPATH='.'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/diamond-31-10-5-5-a-1.lp --br=$TESTSPATH/diamond-31-10-5-5-a-1.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/diamond-31-10-5-5-a-2.lp --br=$TESTSPATH/diamond-31-10-5-5-a-2.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/diamond-31-10-5-5-a-3.lp --br=$TESTSPATH/diamond-31-10-5-5-a-3.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/diamond-31-10-5-5-a-4.lp --br=$TESTSPATH/diamond-31-10-5-5-a-4.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/diamond-31-10-5-5-a-5.lp --br=$TESTSPATH/diamond-31-10-5-5-a-5.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/diamond-31-10-5-5-a-6.lp --br=$TESTSPATH/diamond-31-10-5-5-a-6.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/diamond-31-10-5-5-a-7.lp --br=$TESTSPATH/diamond-31-10-5-5-a-7.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=8 --port=5008 --kb=$TESTSPATH/diamond-31-10-5-5-a-8.lp --br=$TESTSPATH/diamond-31-10-5-5-a-8.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=9 --port=5009 --kb=$TESTSPATH/diamond-31-10-5-5-a-9.lp --br=$TESTSPATH/diamond-31-10-5-5-a-9.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=10 --port=5010 --kb=$TESTSPATH/diamond-31-10-5-5-a-10.lp --br=$TESTSPATH/diamond-31-10-5-5-a-10.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=11 --port=5011 --kb=$TESTSPATH/diamond-31-10-5-5-a-11.lp --br=$TESTSPATH/diamond-31-10-5-5-a-11.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=12 --port=5012 --kb=$TESTSPATH/diamond-31-10-5-5-a-12.lp --br=$TESTSPATH/diamond-31-10-5-5-a-12.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=13 --port=5013 --kb=$TESTSPATH/diamond-31-10-5-5-a-13.lp --br=$TESTSPATH/diamond-31-10-5-5-a-13.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=14 --port=5014 --kb=$TESTSPATH/diamond-31-10-5-5-a-14.lp --br=$TESTSPATH/diamond-31-10-5-5-a-14.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=15 --port=5015 --kb=$TESTSPATH/diamond-31-10-5-5-a-15.lp --br=$TESTSPATH/diamond-31-10-5-5-a-15.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=16 --port=5016 --kb=$TESTSPATH/diamond-31-10-5-5-a-16.lp --br=$TESTSPATH/diamond-31-10-5-5-a-16.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=17 --port=5017 --kb=$TESTSPATH/diamond-31-10-5-5-a-17.lp --br=$TESTSPATH/diamond-31-10-5-5-a-17.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=18 --port=5018 --kb=$TESTSPATH/diamond-31-10-5-5-a-18.lp --br=$TESTSPATH/diamond-31-10-5-5-a-18.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=19 --port=5019 --kb=$TESTSPATH/diamond-31-10-5-5-a-19.lp --br=$TESTSPATH/diamond-31-10-5-5-a-19.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=20 --port=5020 --kb=$TESTSPATH/diamond-31-10-5-5-a-20.lp --br=$TESTSPATH/diamond-31-10-5-5-a-20.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=21 --port=5021 --kb=$TESTSPATH/diamond-31-10-5-5-a-21.lp --br=$TESTSPATH/diamond-31-10-5-5-a-21.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=22 --port=5022 --kb=$TESTSPATH/diamond-31-10-5-5-a-22.lp --br=$TESTSPATH/diamond-31-10-5-5-a-22.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=23 --port=5023 --kb=$TESTSPATH/diamond-31-10-5-5-a-23.lp --br=$TESTSPATH/diamond-31-10-5-5-a-23.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=24 --port=5024 --kb=$TESTSPATH/diamond-31-10-5-5-a-24.lp --br=$TESTSPATH/diamond-31-10-5-5-a-24.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=25 --port=5025 --kb=$TESTSPATH/diamond-31-10-5-5-a-25.lp --br=$TESTSPATH/diamond-31-10-5-5-a-25.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=26 --port=5026 --kb=$TESTSPATH/diamond-31-10-5-5-a-26.lp --br=$TESTSPATH/diamond-31-10-5-5-a-26.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=27 --port=5027 --kb=$TESTSPATH/diamond-31-10-5-5-a-27.lp --br=$TESTSPATH/diamond-31-10-5-5-a-27.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=28 --port=5028 --kb=$TESTSPATH/diamond-31-10-5-5-a-28.lp --br=$TESTSPATH/diamond-31-10-5-5-a-28.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=29 --port=5029 --kb=$TESTSPATH/diamond-31-10-5-5-a-29.lp --br=$TESTSPATH/diamond-31-10-5-5-a-29.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=30 --port=5030 --kb=$TESTSPATH/diamond-31-10-5-5-a-30.lp --br=$TESTSPATH/diamond-31-10-5-5-a-30.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=31 --port=5031 --kb=$TESTSPATH/diamond-31-10-5-5-a-31.lp --br=$TESTSPATH/diamond-31-10-5-5-a-31.br --topology=$TESTSPATH/diamond-31-10-5-5-a.opt >/dev/null 2>&1 &
/usr/bin/time --portability -o diamond-31-10-5-5-a-dmcsopt-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=31 > diamond-31-10-5-5-a-dmcsopt.log 2> diamond-31-10-5-5-a-dmcsopt-err.log
killall dmcsd
